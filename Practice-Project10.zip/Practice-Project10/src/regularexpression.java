
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regularexpression {

	public static void main(String[] args) {
		  String text = "Dog guard the House";

	        String pattern = "\\b\\w{3}\\b"; 
	       
	        Pattern regexPattern = Pattern.compile(pattern);

	        
	        Matcher matcher = regexPattern.matcher(text);

	       
	        System.out.println("Matching three-letter words:");
	        while (matcher.find()) {
	            System.out.println(matcher.group());
	        }

	        
	        String replacedText = text.replaceAll("\\bDog\\b", "cat");

	        System.out.println("\nAfter replacement:");
	        System.out.println(replacedText);

	}

}
