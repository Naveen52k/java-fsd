
public class typecasting {

	public static void main(String[] args) {
		int intValue = 5;
		double doubleValue = intValue;
		
		System.out.println("Implicit Type Casting: ");
		System.out.println("int value: " + intValue);
		System.out.println("double value: " + doubleValue);
		
		double doubleValue2 = 10.52;
		int intValue2 = (int)doubleValue2;
		
		System.out.println("\nExplicit Type Casting: ");
		System.out.println("double value: "+ doubleValue2);
		System.out.println("int value: "+ intValue2);
		

	}

}
