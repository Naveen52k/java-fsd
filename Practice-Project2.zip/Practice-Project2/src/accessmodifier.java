
import java.util.Scanner;

class MyClass {
    public int publicField = 1;
    private int privateField = 2;
    protected int protectedField = 3;
    int defaultField = 4;

    public MyClass() {
        System.out.println("Public constructor");
    }

    private MyClass(String value) {
        System.out.println("Private constructor");
    }
    
    protected MyClass(int value) {
        System.out.println("Protected constructor");
    }
    
    MyClass(double value) {
        System.out.println("Default (package-private) constructor");
    }

    public void publicMethod() {
        System.out.println("Public method");
    }

    @SuppressWarnings("unused")
	private void privateMethod() {
        System.out.println("Private method");
    }

    protected void protectedMethod() {
        System.out.println("Protected method");
    }

    void defaultMethod() {
        System.out.println("Default (package-private) method");
    }
}

public class accessmodifier {
    @SuppressWarnings("unused")
	public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);
    	
    	System.out.print("Enter a value for publicField: ");
        int publicFieldValue = scanner.nextInt();
        
        System.out.print("Enter a value for protectedField: ");
        int protectedFieldValue = scanner.nextInt();

        System.out.print("Enter a value for defaultField: ");
        int defaultFieldValue = scanner.nextInt();

        System.out.print("Enter a value for privateField: ");
        int privateFieldValue = scanner.nextInt();

        MyClass obj = new MyClass(0);
        
        obj.publicField = publicFieldValue;
        obj.protectedField = protectedFieldValue;
        obj.defaultField = defaultFieldValue;
        
        obj.publicMethod();
        
        scanner.close();
    }
       
    }


