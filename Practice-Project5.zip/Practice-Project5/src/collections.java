
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Map;
public class collections {

	public static void main(String[] args) {
		
		//for Array collection 
		//note: in array duplicates are allowed
		List<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");
        arrayList.add("Apple"); 
        System.out.println("ArrayList:");
        for (String fruit : arrayList) {
        	System.out.println(fruit);
        	
        }
        
        //for hashset collection
        //Note: in hashset the duplicate are not allowed
        
        Set<String> hashSet = new HashSet<>();
        hashSet.add("lemon");
        hashSet.add("Banana");
        hashSet.add("grape");
        hashSet.add("lemon"); 
        System.out.println("\nHashSet:");
        for (String fruit : hashSet) {
            System.out.println(fruit);
        }
        
        //for hashmap collection
        // Note: in hashmap replaces the before value for repeated item
        
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Apple", 5);
        hashMap.put("Banana", 5);
        hashMap.put("Orange", 6);
        hashMap.put("Apple", 2);
        System.out.println("\nHashMap:");
        for (String fruit : hashMap.keySet()) {
            int quantity = hashMap.get(fruit);
            System.out.println(fruit + ": " + quantity);
        }
            
	}

}
