
import java.util.Scanner;

public class calculator {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		double num1, num2, result;
		char operator;
		
		System.out.println("Arithmetic Calculator");
		System.out.println("enter the first number: ");
		num1 = scanner.nextDouble();
		System.out.println("enter the Arithmetic operators(+, -, /, *): ");
		operator = scanner.next().charAt(0);
		System.out.println("enter the second number: ");
		num2 = scanner.nextDouble();
		
		switch(operator) {
		case '+':
			result = num1 + num2;
			System.out.println("result: " + result);
			break;
		case '-':
			result = num1 - num2;
			System.out.println("result: " + result);
			break;
		case '*':
			result = num1 * num2;
			System.out.println("result: " + result);
			break;
		case '/':
			if (num2 !=0) {
			result = num1 / num2;
			System.out.println("result: " + result);
			}else {
			System.out.println("number divided by zero = 0");
			}
			break;
		default:
			System.out.println("invalid operator");
		
		}
		
		scanner.close();

	}

}
