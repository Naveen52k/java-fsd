
public class callingmethod {
	
	
	public static void main(String[] args) {
		
		int add = methods.add(6, 6);
	System.out.println("Sum: " + add);
		
	}

}

	
	


