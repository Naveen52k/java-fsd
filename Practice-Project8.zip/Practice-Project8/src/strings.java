
public class strings {

	public static void main(String[] args) {
		String text = "Im, Naveen";

        // Convert the string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(text);

        // Convert the string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(text);

        // Display the original string
        System.out.println("Original String: " + text);

        // Display the StringBuffer and StringBuilder
        System.out.println("StringBuffer: " + stringBuffer.toString());
        System.out.println("StringBuilder: " + stringBuilder.toString());

	}

}
