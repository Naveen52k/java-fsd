
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
public class maps {

	public static void main(String[] args) {
		
		
		Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("ussop", 50);
        hashMap.put("hinata", 60);
        hashMap.put("goku", 98);

        System.out.println("HashMap:");
        for (String key : hashMap.keySet()) {
            int age = hashMap.get(key);
            System.out.println(key + ": " + age);
        }

        // TreeMap (sorted by keys)
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("zoro", 80);
        treeMap.put("sanji", 75);
        treeMap.put("luffy", 100);

        System.out.println("\nTreeMap:");
        for (String key : treeMap.keySet()) {
            int age = treeMap.get(key);
            System.out.println(key + ": " + age);
        }

	}
}
