
class MyClass {
    private int value;
    
    public MyClass(int value) {
        System.out.println("Parameterized Constructor called");
        this.value = value;
    }

    
    public MyClass(int value, boolean chained) {
        this(value);
        System.out.println("Chained Constructor called");
    }

    public void displayValue() {
        System.out.println("Value: " + value);
    }
}

public class constructors {

	public static void main(String[] args) {
		    MyClass obj1 = new MyClass(0); 
	        MyClass obj2 = new MyClass(42); 
	        MyClass obj3 = new MyClass(123, true); 

	        // Displaying values
	        obj1.displayValue(); 
	        obj2.displayValue(); 
	        obj3.displayValue();

	}

}
