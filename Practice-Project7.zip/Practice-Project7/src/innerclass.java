
class OuterClass {
    private int outerField = 10;

    class InnerClass {
        void display() {
            System.out.println("Inner Class: " + outerField);
        }
    }

    public void useInnerClasses() {
        // Local Inner Class
        class LocalInner {
            void display() {
                System.out.println("Local Inner: " + outerField);
            }
        }
        
        InnerClass innerclass = new InnerClass();
        LocalInner localInner = new LocalInner();

        innerclass.display();
        localInner.display();
    }
}
public class innerclass {

	public static void main(String[] args) {
		OuterClass outer = new OuterClass();
        outer.useInnerClasses();

        Runnable anonymousInner = new Runnable() {
            @Override
            public void run() {
                System.out.println("Anonymous Inner: Running...");
            }
        };

        Thread thread = new Thread(anonymousInner);
        thread.start();

	}

}
