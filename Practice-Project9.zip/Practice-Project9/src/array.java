
public class array {

	public static void main(String[] args) {
		int[] intArray = { 1, 6, 3, 4, 5 };

        System.out.print("Array elements: ");
        for (int i = 0; i < intArray.length; i++) {
            System.out.print(intArray[i] + " ");
        }
        System.out.println();

        String[] stringArray = { "Apple", "Banana", "Cherry", "Date", "Fig" };

        System.out.print("String array elements: ");
        for (int i = 0; i < stringArray.length; i++) {
            System.out.print(stringArray[i] + " ");
        }
        System.out.println();

	}

}
